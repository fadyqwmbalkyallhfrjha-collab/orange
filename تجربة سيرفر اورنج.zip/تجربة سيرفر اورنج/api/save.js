import express from "express";
import bodyParser from "body-parser";
import { createClient } from "@supabase/supabase-js";

const app = express();
app.use(bodyParser.json());

// تهيئة Supabase باستخدام المتغيرات البيئية في Render
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

// نقطة النهاية /api/save
app.post("/api/save", async (req, res) => {
  const { name, idNumber, loanAmount, address, job, orange } = req.body;

  try {
    const { data, error } = await supabase
      .from("loan_requests")
      .insert([{ name, idNumber, loanAmount, address, job, orange }]);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    return res.status(200).json({ message: "تم حفظ البيانات بنجاح", data });
  } catch (err) {
    return res.status(500).json({ error: "خطأ في السيرفر: " + err.message });
  }
});

// إذا كان الطلب ليس POST
app.use("/api/save", (req, res) => {
  res.status(405).json({ error: "Method Not Allowed" });
});

// تشغيل السيرفر على Render
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
